<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\ProductColorRequest;
use App\Models\Admin\ProductColor;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Http\Request;

class ProductColorController extends Controller
{

}
