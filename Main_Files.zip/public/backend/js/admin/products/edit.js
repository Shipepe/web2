(function($) {
    "use strict";

    $(".tag_one").select2();
    $(".tag_two").select2();

    $('#discount').on('keyup', function () {
        var price = $('#price').val();
        var discount = $('#discount').val();
        var discount_price = (price * (100 - discount)) / 100;
        $('#discount_price').val(discount_price);
    })

    $('#en-product-name').on('keyup', function() {
        let $this = $(this);
        let str = $this.val().toLowerCase().replace(/[0-9`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi,'-').replace(/ /g, '-');
        $('#en-product-slug').val(str);
    })

    $('#fr-product-name').on('keyup', function() {
        let $this = $(this);
        let str = $this.val().toLowerCase().replace(/[0-9`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi,'-').replace(/ /g, '-');
        $('#fr-product-slug').val(str);
    })
})(jQuery)
