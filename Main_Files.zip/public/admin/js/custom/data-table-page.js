 /*---------------------------
 DataTable page
 ---------------------------*/
 //customers table
 $('#customers-table').DataTable({
    //"paging": false,
    "info": false,
    //searching: false,
});

//project list table
$('#project-list-table').DataTable({
    //"paging": false,
    "info": false,
    //searching: false,
});

//filter table
$('#filter-table').DataTable({
    "paging": false,
    "info": false,
    searching: false,
});